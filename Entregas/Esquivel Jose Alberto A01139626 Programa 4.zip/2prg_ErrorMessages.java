package mx.itesm.A01139626.src;
//&p-ErrorMessages
//&b=2
public interface ErrorMessages {
	public final String sINVALID_INTEGER = "Favor de introducir solamente valores enteros mayores a 0."; //&m
	
	public final String sINVALID_REAL_NUMBER = "Favor de introducir solamente valores numéricos reales mayores o iguales a 0."; //&m

	public final String sIO_EXCEPTION = "Hubo un error al leer datos. Lo sentimos, intente nuevamente.";
}
