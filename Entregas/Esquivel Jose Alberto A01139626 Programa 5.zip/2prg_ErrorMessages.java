package mx.itesm.A01139626.p5.src;
//&p-ErrorMessages
//&b=4
public interface ErrorMessages {
	public final String sINVALID_INTEGER = "Favor de introducir solamente valores enteros mayores a 0."; //&m
	
	public final String sINVALID_REAL_NUMBER = "Favor de introducir solamente valores numéricos reales mayores o iguales a 0.";

	public final String sIO_EXCEPTION = "Hubo un error al leer datos. Lo sentimos, intente nuevamente.";

	public final String sINVALID_PVALUE = "Favor de introducir solamente valores numéricos reales entre 0 y 0.5.";
}
